<button class="chatbot-toggler">
  <span class="material-symbols-rounded">mode_comment</span>
  <span class="material-symbols-outlined">close</span>
</button>
<div class="chatbot chat-wrapper">
  <section class="chat-area">
      <header>
        <img src="img/image2.jpg" alt="">
        <div class="details">
            <span>KDMotoshop</span>
            <p>Active now</p>
        </div>                    
      </header>
      <div class="chat-box"></div>

      <form action="#" class="typing-area" autocomplete="off">
        <input type="text" name="outgoing_id" value="<?php echo $_SESSION['unique_id'] ?>" hidden>
        <input type="text" name="message" class="input-field" placeholder="Enter a message...">
        <button type="submit"><i class="fa fa-paper-plane"></i></button>
      </form>
  </section>
</div>