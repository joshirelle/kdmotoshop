<?php

// $sql = "INSERT INTO `payment_info`
// 			(`item_number`, `item_name`, `payment_status`,
// 				 `amount`, `currency`, `txn_id`)
// 			VALUES
// 			(:item_number, :item_name, :payment_status, 
// 				:amount, :currency, :txn_id)";
// 		$pdo_statement = $pdo_conn->prepare($sql);
//         $result = $pdo_statement->execute(array(':item_number' => $item_number, ':item_name' => $item_name, ':payment_status' => $payment_status, ':amount' => $amount, ':currency' => $currency, ':txn_id' => $txn_id));
