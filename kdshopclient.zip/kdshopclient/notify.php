<?php session_start(); ?>

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script type="text/javascript">
	// Set up PayPal API credentials 
	var client_id = "ARYueR-ApletGMQBNd2UzX-urMAd2zNfJ_ZiapicFez44OuKF7Fty90ya0CAQw3KHJGGwT5I4wsWVJ4W"; 
	var client_secret = "EJx20_c7Ot5vpqFc2BuDnhBHPUBYoyt29KSjXgHGCjEePrePDHaXzEfX9xF0HoSisOecVdFjR2HYMD5X"; 
	
	// Set up jQuery Ajax request to get an access token 
	$.ajax({ 
		url: "https://api-m.sandbox.paypal.com/v1/oauth2/token", 
		type: "POST", 
		data: "grant_type=client_credentials", 
		beforeSend: function(xhr) { 
				xhr.setRequestHeader("Authorization", "Basic " + btoa(client_id + ":" + client_secret)); 
		}, 
		success: function(data) { 
			var access_token = data.access_token; 
			
			var url_string = window.location;
			var url = new URL(url_string);
			var token = url.searchParams.get("token");

			//console.log(token);

			// // Set up jQuery Ajax request to create a payment 
			$.ajax({ 
				url: "https://api-m.sandbox.paypal.com/v2/checkout/orders/" + token + "/capture", 
				type: "POST", 
				contentType: "application/json", 
				dataType: "json", 
				beforeSend: function(xhr) { 
					xhr.setRequestHeader("Authorization", "Bearer " + access_token); 
				}, 
				success: function(data) { 
					// Redirect to PayPal for payment approval 
					//console.log(data);
					
					var givenName = data.payer.name.given_name; 
					var surname = data.payer.name.surname;

					var addData = new FormData();
					addData.append('token', token);

					$.ajax({
						data: addData,
						type: "post",
						contentType: false,
						cache: false,
						processData: false,
						url: "crud/orders/create.php",
						success: function(res) {
							//console.log(res);
							window.location.href = "http://localhost/kdshopclient/index.php";
						},
						error: function(e) {
							alert("error while trying to add or update user!");
						}
					});
				} 
			}); 
		}
	});
</script>