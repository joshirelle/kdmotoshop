<?php
header("Location: http://localhost:81/kdshopclient/index.php");
?>
<h1>Sorry! Your PayPal Payment has been cancelled.</h1>