<!-- Shop Start -->
<div class="container-fluid">
    <div class="row px-xl-5">
        <!-- Shop Sidebar Start -->
        <div class="col-lg-3 col-md-4">
            <!-- Price Start -->
            <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Transaction Date</span></h5>
            <div class="bg-light p-4 mb-30">
                <form>
                    <?php
                        if(!empty($paymentRows)) { 
                            foreach($paymentRows as $row) {
                            ?>
                                 <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                                    <input type="checkbox" class="custom-control-input trandate" id="payment-<?php echo $row["id"]; ?>" name="trandate" value="<?php echo $row["id"]; ?>">
                                    <label class="custom-control-label" name="payment-label" for="payment-<?php echo $row["id"]; ?>"><?php echo $row["created_at"]; ?></label>
                                    <span class="badge border font-weight-normal"><?php echo $row["created_at_count"]; ?></span>
                                </div>
                            <?php
                            }
                        }
                    ?>
                </form>
            </div>
            <!-- Price End -->
        </div>
        <!-- Shop Sidebar End -->

        <!-- Shop Product Start -->
        <div class="col-lg-9 col-md-8">
            <div class="row pb-3">
                <table class="table" id="myTable">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Transaction ID</th>
                            <th scope="col">Transaction Date</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
        <!-- Shop Product End -->
    </div>
</div>
<!-- Shop End -->