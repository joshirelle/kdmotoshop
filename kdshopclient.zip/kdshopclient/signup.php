<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>KDMotoshop | Sign Up</title>
	<link rel="stylesheet" type="text/css" href="css/signup-style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="wrapper">
		<section class="form signup">
			<header>Realtime Chat App</header>
			<form id="signup" role="form" method="post" enctype="multipart/form-data">
				<div class="error-txt"></div>
				<div class="name-details">
					<div class="field input">
						<label>First Name</label>
						<input type="text" name="first-name" placeholder="First Name" required>
					</div>
					<div class="field input">
						<label>Last Name</label>
						<input type="text" name="last-name" placeholder="Last Name" required>
					</div>
				</div>
				<div class="field input">
					<label>Email Address</label>
					<input type="text" name="email" placeholder="Enter your email" required>
				</div>
				<div class="field input">
					<label>Password</label>
					<input type="password" name="password" placeholder="Enter new password" required>
				</div>
				<div class="field image">
					<label>Select Image</label>
					<input type="file" name="image" id="image" accept=".jpg, .png" required>
				</div>
				<div class="field button">
					<input type="submit" name="add_user" value="Submit" id="submit">
				</div>
			</form>
			<div class="link">Already Signed Up? <a href="signin.php">Sign In</div>
		</section>
	</div>

	<!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="js/signup.js"></script>
</body>
</html>