<?php
$database_username = 'root';
$database_password = '';
$pdo_conn = new PDO('mysql:host=localhost;dbname=kdmotorshop', $database_username, $database_password);
?>