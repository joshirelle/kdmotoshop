<?php

    try {
        session_start();
        if (!empty($_GET["action"])) {
            switch($_GET["action"]) {
                case "add":
                    if (isset($_POST["name"]) || isset($_GET["name"])) {
                        $name = $_POST["prod_name"];
                    }

                    if (isset($_POST["qty"])) {
                        $qty = $_POST["qty"];
                    }

                    if (isset($_GET["qty"])) {
                        $qty = $_GET["qty"];
                    }

                    $id = $_GET["prod_id"];
                    //echo $name;
    
                    include_once "config/config.php";
                    //echo "Connection has been set successfully";
                    $sql = "SELECT p.prod_id, a.cat_name, b.brand_name, p.name, p.description, p.image, p.qty, p.price, p.is_active
                            FROM categories a 
                            JOIN products p ON a.cat_id = p.cat_id
                            JOIN brands b ON b.brand_id = p.brand_id 
                            WHERE p.prod_id = " . $id;
                    $pdo_statement = $pdo_conn->prepare($sql);
                    $pdo_statement->execute();
                    $prodRows = $pdo_statement->fetchAll();

                    //echo $prodRows[0]["name"];

                    $itemArray = array($prodRows[0]["name"] => array(
                                                                    'prod_id'=>$prodRows[0]["prod_id"], 
                                                                    'name'=>$prodRows[0]["name"], 
                                                                    'image'=>$prodRows[0]["image"], 
                                                                    'qty'=> $qty,
                                                                    'price'=>$prodRows[0]["price"]));
    
                    if(!empty($_SESSION["cart_item"])) {
                        if(in_array($prodRows[0]["name"], array_keys($_SESSION["cart_item"]))) {
                            foreach($_SESSION["cart_item"] as $k => $v) {
                                if($prodRows[0]["name"] == $k) {
                                    if(empty($_SESSION["cart_item"][$k]["qty"])) {
                                        $_SESSION["cart_item"][$k]["qty"] = 0;
                                    }

                                    $_SESSION["cart_item"][$k]["qty"] += $qty;
                                }
                            }
                        } else {
                            $_SESSION["cart_item"] = array_merge($_SESSION["cart_item"], $itemArray);
                        }
                    } else {
                        $_SESSION["cart_item"] = $itemArray;
                    }
                    break;
    
                case "remove":  
                    if(!empty($_SESSION["cart_item"])) {
                        foreach($_SESSION["cart_item"] as $k => $v) {
                                if($_GET["name"] == $k)
                                    unset($_SESSION["cart_item"][$k]);				
                                if(empty($_SESSION["cart_item"]))
                                    unset($_SESSION["cart_item"]);
                        }
                    }
                    break;
            }
        }
    } catch (PDOException $e) {
        echo $e;
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>MultiShop - Online Shop Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php include_once "include/topbar.php"; ?>
    <?php include_once "include/navbar.php"; ?>
    <?php include_once "include/breadcrumb.php"; ?>
    <?php include_once "include/cart.php"; ?>
    <?php include_once "include/footer.php"; ?>

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>
                        
    <script type="text/javascript">
        var sum = 0;
        var newVal = 0;
        // Product Quantity
        
        var total = 0;
        var newTotal = 0;

        $('#products tr').each(function(){
            $(this).find('.total').each(function(){
                var price = $(this).text();
                if (!isNaN(price) && price.length !== 0) {
                    sum += parseFloat(price);
                }
            });

            document.getElementById("subtotal").innerHTML = "₱" + sum;
            document.getElementById("last-total").innerHTML = "₱" + sum;
        })

        $('.quantity button').on('click', function () {
            var button = $(this);
            var oldValue = button.parent().parent().find('input').val();
            if (button.hasClass('btn-plus')) {
                var newVal = parseFloat(oldValue) + 1;
            } else {
                if (oldValue > 0) {
                    var newVal = parseFloat(oldValue) - 1;
                } else {
                    newVal = 0;
                }
            }
            
            button.parent().parent().find('input').val(newVal);

            $('#products').find('tr').click( function(){
                var price = $(this).find('td:nth-child(2)').text();
                var qty = newVal;
                
                var total = price * qty;
                // console.log(total);

                if (!isNaN(total) && total.length !== 0) {
                    $(this).find('td:nth-child(4)').text(total);

                    var currentTotal, newSubTotal = 0;
                    $("#products > tbody > tr").each(function () {
                        currentTotal = $(this).find('td').eq(3).text();
                        console.log(currentTotal);
                        newSubTotal += parseFloat(currentTotal);
                    });

                    document.getElementById("subtotal").innerHTML = "₱" + newSubTotal;
                    document.getElementById("last-total").innerHTML = "₱" + newSubTotal;
                    document.getElementById("total-qty").value = newVal;
                }
            });
        });

        
    </script>

    <!-- Template Javascript -->
    <!-- <script src="js/main.js"></script> -->
</body>

</html>