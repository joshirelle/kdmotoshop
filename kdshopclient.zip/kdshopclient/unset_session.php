<?php
session_start();
unset($_SESSION["cart_item"]);
header("Location: http://localhost:81/kdshopclient/index.php");
?>