<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>KDMotoshop | Sign In</title>
	<link rel="stylesheet" type="text/css" href="css/signin-style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="wrapper">
		<section class="form signin">
			<header>Realtime Chat App</header>
			<form action="index.php">
				<div class="error-txt"></div>
				<div class="field input">
					<label>Email Address</label>
					<input type="text" name="email" class="email" id="email" placeholder="Enter your email">
				</div>
				<div class="field input">
					<label>Password</label>
					<input type="password" name="password" class="password" id="password" placeholder="Enter your password">
					<i class="fa fa-eye"></i>
				</div>
				<div class="field button">
					<input type="submit" name="submit" class="submit" id="submit" value="Login">
				</div>
			</form>
			<div class="link">Not yet Signed Up? <a href="signup.php">Sign Up</div>
		</section>
	</div>

	<!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="js/signin.js"></script>
</body>
</html>