<?php

$firstName = $_POST["firstName"];
$lastName = $_POST["lastName"];
$emailAddr = $_POST["emailAddr"];
$mobileNo = $_POST["mobileNo"];
$addr1 = $_POST["addr1"];
$country = $_POST["country"];
$city = $_POST["city"];
$state = $_POST["state"];
$zip = $_POST["zip"];
$isDefaultAddr = $_POST["isDefaultAddr"];

try {
    include_once "../../config/config.php";

    $sql = "SELECT COUNT(*) FROM billing_address WHERE is_default = 1";
    $pdo_statement = $pdo_conn->prepare($sql);
    $pdo_statement->execute();
    $addrRows = $pdo_statement->fetchAll();

    if ($addrRows[0][0] == 0) {
	$sql = "INSERT INTO billing_address(fname, lname, email, mobile, addr_line, country, city, state, zip, is_default)VALUES(:fname, :lname, :email, :mobile, :addr_line, :country, :city, :state, :zip, :is_default)";

    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':fname'=>$firstName,
											':lname'=>$lastName,
											':email'=>$emailAddr,
											':mobile'=>$mobileNo,
											':addr_line'=>$addr1,
											':country'=>$country,
											':city'=>$city,
											':state'=>$state,
											':zip'=>$zip,
											':is_default'=>$isDefaultAddr));
    } else {
    	$sql = "INSERT INTO billing_address(fname, lname, email, mobile, addr_line, country, city, state, zip)VALUES(:fname, :lname, :email, :mobile, :addr_line, :country, :city, :state, :zip)";
	    $pdo_statement = $pdo_conn->prepare($sql);
	    $result = $pdo_statement->execute(array(':fname'=>$firstName,
												':lname'=>$lastName,
												':email'=>$emailAddr,
												':mobile'=>$mobileNo,
												':addr_line'=>$addr1,
												':country'=>$country,
												':city'=>$city,
												':state'=>$state,
												':zip'=>$zip));
    }

    

    echo "Success";
    
} catch (PDOException $e) {
    echo $e;
}

?>