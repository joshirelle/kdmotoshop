<?php

try {
    include_once "config/config.php";

    $sql = "SELECT * FROM carousel";
    $pdo_statement = $pdo_conn->prepare($sql);
    $pdo_statement->execute();
    $result = $pdo_statement->fetchAll();
} catch (PDOException $e) {
    echo $e;
}