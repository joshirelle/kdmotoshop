<?php

try {
    include_once "config/config.php";
    $user_id = $_SESSION['unique_id'];
    
    //echo "Connection has been set successfully";
    $sql = "SELECT * FROM shop_users WHERE unique_id = :unique_id";
    $pdo_statement = $pdo_conn->prepare($sql);
    $pdo_statement->execute([':unique_id'=> $user_id]);
	$result = $pdo_statement->fetchAll();
} catch (PDOException $e) {
    echo $e;
}