<?php
	session_start();
	include_once "../../config/config.php";

	if (isset($_SESSION['unique_id'])) {
	    $outgoing_msg_id = $_POST['outgoing_id'];
	    $output = "";
	    
	    $sql = "SELECT * FROM messages WHERE (outgoing_msg_id = :outgoing_msg_id OR incoming_msg_id = :outgoing_msg_id) ORDER BY msg_id";
	    $pdo_statement = $pdo_conn->prepare($sql);
	    $pdo_statement->execute([':outgoing_msg_id'=> $outgoing_msg_id]);
		$result = $pdo_statement->fetchAll();

		if(!empty($result)) { 
	        foreach($result as $row) {
	        	if ($row['outgoing_msg_id'] === $outgoing_msg_id) {
	        		$output .= '<div class="chat outgoing">
		                          <div class="details">
		                            <p>' . $row['msg'] . '</p>
		                          </div>
		                        </div>';
	        	}else{ 
	        		$output .= '<div class="chat incoming">
		                          <img src="img/image2.jpg" alt="">
		                          <div class="details">
		                            <p>' . $row['msg'] . '</p>
		                          </div>
		                        </div>';
	        	}
	        }

	        echo $output;
	    }
	}
?>