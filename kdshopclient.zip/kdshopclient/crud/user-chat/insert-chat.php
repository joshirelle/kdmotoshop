<?php
	session_start();
	include_once "../../config/config.php";

	if (isset($_SESSION['unique_id'])) {
	    $outgoing_msg_id = $_POST['outgoing_id'];
	    $msg = $_POST['message'];

	    if (!empty($msg)){
	    	$sql = "INSERT INTO messages(outgoing_msg_id, msg)VALUES(:outgoing_msg_id, :msg)";
		    $pdo_statement = $pdo_conn->prepare($sql);
		    $result = $pdo_statement->execute([':outgoing_msg_id'=>$outgoing_msg_id,
											   ':msg'=>$msg]);

		    echo "success";
	    }else{
	    	echo "message is empty";
	    }
	}else{
		echo "session_id is not set";
	}
?>