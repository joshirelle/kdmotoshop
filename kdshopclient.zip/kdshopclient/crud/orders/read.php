<?php

try {
	session_start();
    include_once "../../config/config.php";

    $arrTranDates = isset($_POST['trandates']) ? $_POST['trandates'] : "";
    $trandate = "";

    if (!empty($arrTranDates)) {
        $trandate = "'" . implode("', '",$arrTranDates) . "'"; 

        $unique_id = $_SESSION['unique_id'];

        $sql = "SELECT txn_id, DATE(created_at) created_at FROM payment_info WHERE unique_id = $unique_id AND DATE(created_at) IN ($trandate)";
        $stmt = $pdo_conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        $arr = [];
        $arr2 = [];
        $output = "";

        $createdAt = "";
        if(!empty($result)) { 
            foreach($result as $row) {
                array_push($arr, array("txn_id"=>$row['txn_id'], "created_at"=>$row['created_at']));
            }

            echo json_encode($arr);
        }
    }
    
} catch (PDOException $e) {
    echo $e;
}

?>