<?php

try {
	session_start();
    include_once "../../config/config.php";

    $txn_id = isset($_GET['token']) ? $_GET['token'] : "";

    $sql = "INSERT INTO payment_info(unique_id, txn_id)VALUES(:unique_id, :txn_id)";
    $stmt = $pdo_conn->prepare($sql);
    $result = $stmt->execute([':unique_id'=>$_SESSION['unique_id'], ':txn_id'=>$txn_id]);
    
    unset($_SESSION["cart_item"]);
    header("location: ../../index.php");
} catch (PDOException $e) {
    echo $e;
}

?>