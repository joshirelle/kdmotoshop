<?php

try {
	session_start();
    include_once "../../config/config.php";

    $email = isset($_POST['email']) ? $_POST['email'] : "";
    $password = isset($_POST['password']) ? $_POST['password'] : "";

    if(!empty($email) && !empty($password)) {
        $sql = "SELECT *, COUNT(*) email FROM shop_users WHERE email = :email AND password = :password";
        $pdo_statement = $pdo_conn->prepare($sql);
        $pdo_statement->execute([':email'=>$email, ':password'=>$password]);
        $result = $pdo_statement->fetchAll();

        foreach($result as $row) {
            if ($row['email'] > 0) {
                $_SESSION['unique_id'] = $row['unique_id'];
                echo "success";
            }else {
                echo "Either email or password is incorrect!";
            }
        }
    } else {
        echo "All input fields are required!";
    }

} catch (PDOException $e) {
    echo $e;
}