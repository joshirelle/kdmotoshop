<?php

try {
	session_start();
    include_once "../../config/config.php";

    $fname = isset($_POST['first-name']) ? $_POST['first-name'] : "";
    $lname = isset($_POST['last-name']) ? $_POST['last-name'] : "";
    $email = isset($_POST['email']) ? $_POST['email'] : "";
    $password = isset($_POST['password']) ? $_POST['password'] : "";
    $image = isset($_POST['image']) ? base64_encode(file_get_contents($_FILES['image']['tmp_name'])) : base64_encode(file_get_contents($_FILES['image']['tmp_name']));

    if (!empty($fname) && !empty($lname) && !empty($email) && !empty($password)) {
    	if (filter_var($email, FILTER_VALIDATE_EMAIL)) {

    		$sql = "SELECT COUNT(email) email FROM shop_users WHERE email = :email";
		    $pdo_statement = $pdo_conn->prepare($sql);
		    $pdo_statement->execute([':email'=>$email]);
			$result = $pdo_statement->fetchAll();

			foreach($result as $row) {
	        	if ($row['email'] > 0) {
	        		echo "$email - This email is already exist!";
	        	} else {
	        		if (isset($_FILES['image'])) {
	        			$img_name = $_FILES['image']['name'];
	        			$tmp_name = $_FILES['image']['tmp_name'];

	        			$img_explode = explode('.', $img_name);
	        			$img_ext = end($img_explode);

	        			$extensions = ['png', 'jpeg', 'jpg'];

	        			if (in_array($img_ext, $extensions) === true) {
	        				$time = time();

	        				$status = "Active Now";	
	        				$random_id = rand(time(), 10000000);

					        $sql2 = "INSERT INTO shop_users(unique_id, fname, lname, email, password, img, status)VALUES(:unique_id, :fname, :lname, :email, :password, :img, :status)";
					        $pdo_statement = $pdo_conn->prepare($sql2);
					        $result = $pdo_statement->execute([':unique_id'=>$random_id,
					    										':fname'=>$fname,
					    										':lname'=>$lname,
					    										':email'=>$email,
					    										':password'=>$password,
					    										':img'=>$image,
					    										':status'=>$status]);

					        if ($result) {
					        	$sql3 = "SELECT * FROM shop_users WHERE email = :email";
							    $pdo_statement = $pdo_conn->prepare($sql3);
							    $pdo_statement->execute([':email'=>$email]);
								$result = $pdo_statement->fetchAll();
								foreach($result as $row) {
						        	$_SESSION['unique_id'] = $row['unique_id'];
						        	echo "success";
						        }
					        }else {
					        	echo "Something went wrong!";
					        }
	        			}else {
	        				echo "Please selec an image file - jpeg, jpg, png!";
	        			}
	        		} else {
	        			echo "Please select an Image File!";
	        		}
	        	}
	        }
    	} else {
    		echo "$email - This is not a valid email!";
    	}
    } else {
    	echo "$fname $lname $email $password All input fields are required!";
    }
   
} catch (PDOException $e) {
    echo $e;
}