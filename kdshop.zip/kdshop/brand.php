<?php

include_once "crud/products/read.php";
include_once "crud/categories/read.php";
include_once "crud/brands/read.php";

include_once "crud/products/count.php";
include_once "crud/categories/count.php";
include_once "crud/brands/count.php";

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>KD Motorshop | Admin</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <?php include_once "include/before-body.php"; ?>
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
      <!-- Main Header -->
      <?php include_once "include/main-header.php"; ?>
      
      <!-- Main Sidebar -->
      <?php include_once "include/main-sidebar.php"; ?>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Brands
            <!-- <small>advanced tables</small> -->
          </h1>
         
          <ol class="breadcrumb">
            <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Maintenance</a></li>
            <li class="active">Brands</li>
          </ol>
        </section>

        <!-- Main content -->
        <?php include_once "include/brand-main-content.php"; ?>
        
      </div><!-- /.content-wrapper -->
      <?php include_once "include/footer.php"; ?>

    </div><!-- ./wrapper -->

    <?php include_once "include/after-footer.php"; ?>
    <?php include_once "include/brand-page-script.php"; ?>
  </body>
</html>
