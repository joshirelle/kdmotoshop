<?php
session_start();
session_regenerate_id(true);

$database_username = 'root';
$database_password = '';
$pdo_conn = new PDO('mysql:host=localhost;dbname=kdmotorshop', $database_username, $database_password);
?>