<section class="content">
    <div class="row">
    <div class="col-xs-12">

        <div class="box">
        <div class="box-header">
            <h3 class="box-title">Masterlist of registered product brands</h3>
            <!-- Button trigger modal -->
            <div style="float: right;">
            <button action-name="add" id="add" type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal" onClick="chk_control('dsb')";>
                Add New
            </button>
            </div>
        </div><!-- /.box-header -->
        <div class="box-body">
            <table id="example1" class="table table-bordered table-striped" style="table-layout: fixed;">
            <thead>
                <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Active</th>
                <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
                $id = 1;
                if(!empty($brandRows)) { 
                foreach($brandRows as $row) {
                ?>
                <tr>
                <td><?php echo $id ?></td>
                <td><?php echo $row["brand_name"]; ?></td>
                <td brand-active="<?php echo $row["is_active"]; ?>"><?php echo ($row["is_active"] == 1) ? "Yes" : "No"; ?></td>
                <td>
                    <button action-name="edit" brand-name="<?php echo $row['brand_name']; ?>" brand-is-active="<?php echo $row['is_active']; ?>" class="btn btn-primary update" id="update" data-toggle="modal" data-target="#exampleModal">
                    Edit
                    </button>
                    <button class="btn btn-danger" id="delete">Delete</button>
                </td>
                </tr>
                <?php

                $id += 1;
                }
                }
                ?>
            </tbody>
            </table>
        </div><!-- /.box-body -->
        </div><!-- /.box -->

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <form id="brandForm" role="form" method="post">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
                </div>
                <div class="modal-body">
                    <div class="box-body">
                    <div class="form-group">
                        <label for="brandName">Name</label>
                        <input type="text" name="brandName" class="form-control" id="brandName" placeholder="Please enter name of brand">
                        
                        <input type="hidden" name="oldBrandName" class="form-control" id="oldBrandName" placeholder="" disabled>
                        <input type="hidden" name="inputIsActive" class="form-control" id="inputIsActive" placeholder="" disabled>
                    </div>
                    <div class="checkbox">
                        <label>
                        <input type="checkbox" name="myCheck" id="myCheck" checked disabled> Active
                        </label>
                    </div>
                    </div>
                </div>
                <div class="modal-footer">
                <input type="submit" name="add_record" class="btn btn-primary" id="submit" value="Submit">
                <input type="button" name="close" class="btn btn-secondary" value="Close" data-dismiss="modal">
                </div>
            </div>
            </form>
            </div>
        </div>
    </div><!-- /.col -->
    </div><!-- /.row -->
</section><!-- /.content -->