<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2023-2024 <a href="https://www.facebook.com/KDmotoshop/">KD Motoshop</a>.</strong> All rights reserved.
</footer>