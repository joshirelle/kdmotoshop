<!-- page script -->
<script type="text/javascript">
    $(function () {
    $("#example1").dataTable();
    $('#example2').dataTable({
        "bPaginate": true,
        "bLengthChange": false,
        "bFilter": false,
        "bSort": true,
        "bInfo": true,
        "bAutoWidth": false
    });
    });

    $('#exampleModal').on('show.bs.modal', function (e) {
    // get information to update quickly to modal view as loading begins
    var opener=e.relatedTarget;//this holds the element who called the modal
    
    //we get details from attributes
    var brandname=$(opener).attr('brand-name');
    var actionName=$(opener).attr('action-name');
    var brandIsActive=$(opener).attr('brand-is-active');
    
    document.getElementById("exampleModalLabel").innerHTML = (actionName == "add") ? "Add New Brand" : "Edit Brand";

    //set what we got to our form
    $('#brandForm').find('[name="brandName"]').val(brandname);
    $('#brandForm').find('[name="oldBrandName"]').val(brandname);
    $('#brandForm').find('[name="inputIsActive"]').val(brandIsActive);
    
    document.getElementById("myCheck").disabled = (actionName == "add" ? true : false);
    
    if (actionName == "edit") {
        document.getElementById("myCheck").checked = (brandIsActive == 1) ? true : false;
    }

    $(document).on('click', '#submit', function(e) {
        //var data = $("#catForm").serialize();
        var brandName = $('#brandForm').find('[name="brandName"]').val();
        var oldBrandName = $('#brandForm').find('[name="oldBrandName"]').val();
        
        var isChecked = document.getElementById("myCheck").checked;
        var isActive = (isChecked == true) ? 1 : 0;

        $.ajax({
        data: (actionName == "add") ? {brandName: brandName} : {brandName: brandName, isActive: isActive, oldBrandName: oldBrandName},
        type: "post",
        url: (actionName == "add") ? "crud/brands/create.php" : "crud/brands/update.php",
        success: function(res) {
            location.reload();
        }
        });
    });
    });

    $(document).on('click', '#delete', function (e) {
        var brandName = $(this).parents('tr').find("td:eq(1)").text();
        //alert(catName);
        $.ajax({
        data: {brandName: brandName},
        type: "post",
        url: "../crud/brands/delete.php",
        success: function(res) {
            //alert("Selected record has been deleted successfully");
            location.reload();
        }
        });
    });

</script>