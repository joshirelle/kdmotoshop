<!-- page script -->
<script type="text/javascript">
    $(function () {
    $("#example1").dataTable();
    $('#example2').dataTable({
        "bPaginate": true,
        "bLengthChange": false,
        "bFilter": false,
        "bSort": true,
        "bInfo": true,
        "bAutoWidth": false
    });
    });

    $('#exampleModal').on('show.bs.modal', function (e) {
    // get information to update quickly to modal view as loading begins
    var opener=e.relatedTarget;//this holds the element who called the modal
    //we get details from attributes

    var catname=$(opener).attr('cat-name');
    var actionName=$(opener).attr('action-name');
    var catIsActive=$(opener).attr('cat-is-active');

    document.getElementById("exampleModalLabel").innerHTML = (actionName == "add") ? "Add New Category" : "Edit Category";

    //set what we got to our form
    $('#catForm').find('[name="catName"]').val(catname);
    $('#catForm').find('[name="oldCatName"]').val(catname);
    $('#catForm').find('[name="inputIsActive"]').val(catIsActive);

    document.getElementById("myCheck").disabled = (actionName == "add" ? true : false);
    
    if (actionName == "edit") {
        document.getElementById("myCheck").checked = (catIsActive == 1) ? true : false;
    }

    $(document).on('click', '#submit', function(e) {
        //var data = $("#catForm").serialize();
        var catName = $('#catForm').find('[name="catName"]').val();
        var oldCatName = $('#catForm').find('[name="oldCatName"]').val();
        
        var isChecked = document.getElementById("myCheck").checked;
        var isActive = (isChecked == true) ? 1 : 0;

        $.ajax({
        data: (actionName == "add") ? {catName: catName} : {catName: catName, isActive: isActive, oldCatName: oldCatName},
        type: "post",
        url: (actionName == "add") ? "crud/categories/create.php" : "crud/categories/update.php",
        success: function(res) {
            location.reload();
        }
        });
    });
    });

    $(document).on('click', '#delete', function (e) {
        var catName = $(this).parents('tr').find("td:eq(1)").text();
        //alert(catName);
        $.ajax({
        data: {catName: catName},
        type: "post",
        url: "../crud/categories/delete.php",
        success: function(res) {
            //alert("Selected record has been deleted successfully");
            location.reload();
        }
        });
    });

</script>