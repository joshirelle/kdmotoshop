<section class="content">
    <div class="row">
        <div class="col-xs-12">

            <div class="box">
                
                <!-- Tab links -->
                <div class="tab">
                <button class="tablinks" onclick="openCity(event, 'Carousel')" id="defaultOpen">Carousel</button>
                <!-- <button class="tablinks" onclick="openCity(event, 'Paris')">Paris</button>
                <button class="tablinks" onclick="openCity(event, 'Tokyo')">Tokyo</button> -->
                </div>

                <form method="post" action="crud/carousel/create.php" role="form" enctype="multipart/form-data">
                    <!-- Tab content -->
                    <div id="Carousel" class="tabcontent">
                        <label for="title"><b>Title</b></label>
                        <input type="text" class="form-control" placeholder="Please enter carousel title" name="title" required>
                        <br>
                        <label for="desc">Description</label>
                        <textarea name="desc" class="form-control" id="desc" placeholder="Please enter carousel description" required></textarea>
                        <br>
                        <label>Select Image File:</label>
                        <input type="file" name="image" id="image" accept=".jpg, .png">
                        <br>
                        <div class="modal-footer">
                            <input type="submit" name="add_record" class="btn btn-primary" id="submit" value="Submit">
                        </div>
                    </div>
                    
                </form>

                <!-- <div id="Paris" class="tabcontent">
                <h3>Paris</h3>
                <p>Paris is the capital of France.</p>
                </div>

                <div id="Tokyo" class="tabcontent">
                <h3>Tokyo</h3>
                <p>Tokyo is the capital of Japan.</p>
                </div> -->
 
            </div><!-- /.box -->
            
        </div><!-- /.col -->
    </div><!-- /.row -->
</section><!-- /.content -->