<?php

try {
    include_once "../../config/config.php";

    //echo "Connection has been set successfully";
    $sql = "INSERT INTO categories(cat_name)VALUES(:catName)";
    $pdo_statement = $pdo_conn->prepare($sql);
        
    $result = $pdo_statement->execute(array(':catName'=>$_POST['catName']));
    // if (!empty($result) ){
    //     header('Location: '.$_SERVER['PHP_SELF']);
    // }
} catch (PDOException $e) {
    echo $e;
}