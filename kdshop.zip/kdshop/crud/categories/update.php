<?php

try {
    include_once "../../config/config.php";

    //echo "Connection has been set successfully";
    $sql = "UPDATE categories SET cat_name = :catName, is_active = :isActive WHERE cat_name = :oldCatName";
    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':catName' => $_POST['catName'], 'isActive' => $_POST['isActive'], ':oldCatName'  => $_POST['oldCatName']));
    // if (!empty($result) ){
    //     header('Location: '.$_SERVER['PHP_SELF']);
    // }
} catch (PDOException $e) {
    echo $e;
}