<?php

try {
    include_once "../../config/config.php";

    //echo "Connection has been set successfully";
    $sql = "DELETE FROM brands WHERE brand_name = :brandName";
    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':brandName' => $_POST['brandName']));
} catch (PDOException $e) {
    echo $e;
}