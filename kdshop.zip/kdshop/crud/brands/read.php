<?php

try {
    include_once "config/config.php";

    //echo "Connection has been set successfully";
    $sql = "SELECT brand_id, brand_name, is_active FROM brands ORDER BY brand_name";
    $pdo_statement = $pdo_conn->prepare($sql);
    $pdo_statement->execute();
	$brandRows = $pdo_statement->fetchAll();
} catch (PDOException $e) {
    echo $e;
}