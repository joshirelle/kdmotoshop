<?php

try {
    include_once "config/config.php";

    //echo "Connection has been set successfully";
    $sql = "SELECT COUNT(*) total FROM brands";
    $pdo_statement = $pdo_conn->prepare($sql);
    $pdo_statement->execute();
	$brandRowCount = $pdo_statement->fetchAll();
} catch (PDOException $e) {
    echo $e;
}