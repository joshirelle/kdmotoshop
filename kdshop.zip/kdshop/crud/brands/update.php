<?php

try {
    include_once "../../config/config.php";

    //echo "Connection has been set successfully";
    $sql = "UPDATE brands SET brand_name = :brandName, is_active = :isActive WHERE brand_name = :oldBrandName";
    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':brandName' => $_POST['brandName'], 'isActive' => $_POST['isActive'], ':oldBrandName'  => $_POST['oldBrandName']));
    // if (!empty($result) ){
    //     header('Location: '.$_SERVER['PHP_SELF']);
    // }
} catch (PDOException $e) {
    echo $e;
}