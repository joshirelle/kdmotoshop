<?php

try {
    include_once "../../config/config.php";

    //echo "Connection has been set successfully";
    $sql = "DELETE FROM products WHERE name = :name";
    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':name' => $_POST['name']));
} catch (PDOException $e) {
    echo $e;
}