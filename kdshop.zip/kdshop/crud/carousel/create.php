<?php

try {
    include_once "../../config/config.php";
    $title = $_POST["title"];
    $description = $_POST["desc"];

    $image = base64_encode(file_get_contents($_FILES['image']['tmp_name']));

    //echo "Connection has been set successfully";
    $sql = "INSERT INTO carousel(title, description, image)VALUES(:title, :description, :image)";
    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':title' => $title, ':description' => $description, ':image' => $image));
    header('Location: http://localhost:81/kdshop/settings.php');
} catch (PDOException $e) {
    echo $e;
}