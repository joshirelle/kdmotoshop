<?php

try {
    include_once "config/config.php";

    $sql = "SELECT * FROM billing_address WHERE is_default = 1";
    $pdo_statement = $pdo_conn->prepare($sql);
    $pdo_statement->execute();
    $addrRows = $pdo_statement->fetchAll();

    $sql = "SELECT * FROM billing_address WHERE is_deleted = 0";
    $pdo_statement = $pdo_conn->prepare($sql);
    $pdo_statement->execute();
    $addr = $pdo_statement->fetchAll();
} catch (PDOException $e) {
    echo $e;
}