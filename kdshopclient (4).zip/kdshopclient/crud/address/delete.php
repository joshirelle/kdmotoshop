<?php

$addressID = $_POST['addressID'];

try {
    include_once "../../config/config.php";

    $sql = "DELETE FROM billing_address WHERE addr_id = :addressID";

    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':addressID'=>$addressID));
} catch (PDOException $e) {
    echo $e;
}

?>