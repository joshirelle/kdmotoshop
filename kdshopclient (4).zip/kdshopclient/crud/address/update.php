<?php

$def_address_id = $_POST['def_address_id'];
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$emailAddr = $_POST['emailAddr'];
$mobileNo = $_POST['mobileNo'];
$addr1 = $_POST['addr1'];
$country = $_POST['country'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$isDefaultAddr = $_POST['isDefaultAddr'];
$addressID = $_POST['addressID'];

try {
    include_once "../../config/config.php";

	if($isDefaultAddr == 1) {
		$sql = "UPDATE billing_address SET is_default = 0 WHERE addr_id = (SELECT addr_id FROM billing_address WHERE is_default = 1)";

		    $pdo_statement = $pdo_conn->prepare($sql);
		    $result = $pdo_statement->execute();
	}

    $sql = "UPDATE billing_address SET fname = :fname, lname = :lname, email = :email, mobile = :mobile, 
    addr_line = :addr_line, country = :country, city = :city, state = :state, zip = :zip, is_default = :is_default WHERE addr_id = :addressID";

    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':fname'=>$firstName,
											':lname'=>$lastName,
											':email'=>$emailAddr,
											':mobile'=>$mobileNo,
											':addr_line'=>$addr1,
											':country'=>$country,
											':city'=>$city,
											':state'=>$state,
											':zip'=>$zip,
											':is_default'=>$isDefaultAddr,
											':addressID'=>$addressID));
   
} catch (PDOException $e) {
    echo $e;
}

?>