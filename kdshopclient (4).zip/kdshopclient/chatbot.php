 <button class="chatbot-toggler">
      <span class="material-symbols-rounded">mode_comment</span>
      <span class="material-symbols-outlined">close</span>
    </button>
 <div class="chatbot">
      <header>
        Chat Assistance
        <span class="close-btn material-symbols-outlined">close</span>
      </header>
      <ul class="chatbox">
        <li class="chat incoming">
          <span class="material-symbols-outlined">smart_toy</span>
          <p>Hi there 👋<br />How can I help you today? 
          <select class="form-control select-option">
            <option selected="javascript:void(0);">Select an option</option>
            <option>Contact details</option>
            <option>Shop location</option>
            <option>Store hours</option>
            <option>Is this free installation?</option>
            <option>Promos and Discounts</option>
            <option>Mode of Payment</option>
            <option>Is Cash on Delivery available?</option>
            <option>Other online shopping platforms</option>
            <option>Guide for installation</option>
            <option>Available top box brand</option>
          </select>
      </p>
        </li>
        <br>
      </ul>
      <div class="chat-input">
        <textarea placeholder="Enter a message..." spellcheck="false" required disabled></textarea>
        <span id="send-btn" class="material-symbols-rounded">send</span>
      </div>
    </div>