<?php

include_once "config/config.php";

$sql = "SELECT p.prod_id, a.cat_name, b.brand_name, p.name, p.description, p.image, p.qty, p.price, p.is_active
        FROM categories a 
        JOIN products p ON a.cat_id = p.cat_id
        JOIN brands b ON b.brand_id = p.brand_id 
        WHERE p.is_active = 1";
        $pdo_statement = $pdo_conn->prepare($sql);
        $pdo_statement->execute();
        $prodRows = $pdo_statement->fetchAll();

$sql = "SELECT prod_id, price, COUNT(price) price_count FROM products WHERE is_active = 1 GROUP BY price";
        $pdo_statement = $pdo_conn->prepare($sql);
        $pdo_statement->execute();
        $priceRows = $pdo_statement->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>MultiShop - Online Shop Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Google Fonts Link For Icons -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,1,0" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/chatbot-style.css" rel="stylesheet">
</head>

<body>
    <?php include_once "include/topbar.php"; ?>
    <?php include_once "include/navbar.php"; ?>
    <?php include_once "include/breadcrumb.php"; ?>
    <?php include_once "include/shop.php"; ?>
    <?php include_once "include/footer.php"; ?>

    <?php include_once "chatbot.php"; ?>

    <!-- Back to Top -->
    <!-- <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a> -->

    <script src="js/chatbot.js" type="text/javascript"></script>
    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

</body>

</html>