<?php

$fname = $_POST["first-name"];
echo $fname;

if (isset($_POST["submit-btn"])) {
	header("Location: https://www.sandbox.paypal.com/cgi-bin/webscr");
	exit();
}

?>
