<?php   
    session_start();    
    $total_qty = isset($_POST["total-qty"]) ? $_POST["total-qty"] : 0;
    $arr = [];
    $array_string = "";

    include_once "crud/address/read.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>KDMotoshop | Checkout</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Google Fonts Link For Icons -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,1,0" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/chatbot-style.css" rel="stylesheet">
</head>

<body>
    <?php include_once "include/topbar.php"; ?>
    <?php include_once "include/navbar.php"; ?>
    <?php include_once "include/breadcrumb.php"; ?>
    <?php include_once "include/checkout.php"; ?>
    <?php include_once "include/footer.php"; ?>

    <?php include_once "chatbot.php"; ?>

    <!-- Back to Top -->
    <!-- <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a> -->

    <script src="js/chatbot.js" type="text/javascript"></script>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script type="text/javascript">
        $actionName = "";

        $("#add-new-address").click(function(e) {
            $("#exampleModalCenter").modal('hide');
            document.getElementById("exampleAddEditModalCenter").setAttribute("action-name", "add");
            $("#exampleAddEditModalCenter").modal('show'); 
        });

        $(".delete-address").click(function(e) {
            var addressID = $(this).attr('data-params');

            $.ajax({
                data: {addressID: addressID},
                type: "post",
                url: "crud/address/delete.php",
                success: function(res) { location.reload(); }
            });
        });

        $(".edit-address").click(function(e) {
            $("#exampleModalCenter").modal('hide');

            var dataParams = $(this).attr('data-params');

            document.getElementById("exampleAddEditModalCenter").setAttribute("action-name", "edit");
            document.getElementById("exampleAddEditModalCenter").setAttribute("address-id", dataParams);

            var firstName = $(this).attr('first-name');
            var lastName = $(this).attr('last-name');
            var email = $(this).attr('email');
            var mobile = $(this).attr('mobile');
            var addr_line = $(this).attr('addr_line');
            var country = $(this).attr('country');
            var city = $(this).attr('city');
            var state = $(this).attr('state');
            var zip = $(this).attr('zip');
            var isDefault = ($(this).attr('is-default') == 1) ? true : false;

            $('#exampleAddEditModalCenter').find('[name="default_address_id"]').val(dataParams);
            $('#exampleAddEditModalCenter').find('[name="input-first-name"]').val(firstName);
            $('#exampleAddEditModalCenter').find('[name="input-last-name"]').val(lastName);
            $('#exampleAddEditModalCenter').find('[name="input-email"]').val(email);
            $('#exampleAddEditModalCenter').find('[name="input-mobile').val(mobile);
            $('#exampleAddEditModalCenter').find('[name="input-address1"]').val(addr_line);
            $('#exampleAddEditModalCenter').find('[name="choose-country"]').val(country);
            $('#exampleAddEditModalCenter').find('[name="input-city"]').val(city);
            $('#exampleAddEditModalCenter').find('[name="input-state"]').val(state);
            $('#exampleAddEditModalCenter').find('[name="input-zip"]').val(zip);
            $('#exampleAddEditModalCenter').find('[name="choose-as-default-addr"]')[0].checked = isDefault;
            
            var isDefaultBillingAddr=document.getElementById("choose-as-default-addr").checked;

            $("#exampleAddEditModalCenter").modal('show'); 
        });

        $('#exampleAddEditModalCenter').on('show.bs.modal', function (e) {
            // get information to update quickly to modal view as loading begins
            var opener=e.relatedTarget;//this holds the element who called the modal
            
            //we get details from attributes
            var actionName = $(this).attr('action-name');
            var addressID = $(this).attr('address-id');
            var billAddrFrm = document.getElementById('billing-addr-form');
            var chooseAsDefAddr = document.getElementById("choose-as-default-addr");

            $(document).on('click', '#btn-submit', function(e) {
                e.preventDefault();

                //var data = $("#catForm").serialize();
                var def_address_id = $(billAddrFrm).find('[name="default_address_id"]').val();
                var firstName = $(billAddrFrm).find('[name="input-first-name"]').val();
                var lastName = $(billAddrFrm).find('[name="input-last-name"]').val();
                var emailAddr = $(billAddrFrm).find('[name="input-email"]').val();
                var mobileNo = $(billAddrFrm).find('[name="input-mobile').val();
                var addr1 = $(billAddrFrm).find('[name="input-address1"]').val();
                var country = $(billAddrFrm).find('[name="choose-country"]').val();
                var city = $(billAddrFrm).find('[name="input-city"]').val();
                var state = $(billAddrFrm).find('[name="input-state"]').val();
                var zip = $(billAddrFrm).find('[name="input-zip"]').val();
                
                var isDefaultBillingAddr= chooseAsDefAddr.checked;
                var isDefaultAddr = (isDefaultBillingAddr == true) ? 1 : 0;

                if (firstName != "" && lastName != "" &&
                    emailAddr != "" && mobileNo != "" &&
                    addr1 != "" && country != "" && city != "" &&
                    state != "" && zip != "") {
                    $.ajax({
                    data: (actionName == "add") 
                            ? {
                            firstName: firstName,
                            lastName: lastName,
                            emailAddr: emailAddr,
                            mobileNo: mobileNo,
                            addr1: addr1,
                            country: country,
                            city: city,
                            state: state,
                            zip: zip,
                            isDefaultAddr: isDefaultAddr} 

                            // edit address
                            : {
                            def_address_id: def_address_id,
                            firstName: firstName,
                            lastName: lastName,
                            emailAddr: emailAddr,
                            mobileNo: mobileNo,
                            addr1: addr1,
                            country: country,
                            city: city,
                            state: state,
                            zip: zip,
                            isDefaultAddr: isDefaultAddr,
                            addressID: addressID},
                    type: "post",
                    url: (actionName == "add") ? "crud/address/create.php" : "crud/address/update.php",
                    success: function(res) {
                        //alert(res);
                        location.reload();
                        }
                    });
                }
            });

            $(document).on('click', '#btn-close', function(e) {
                $('#exampleAddEditModalCenter').find('[name="default_address_id"]').val('');
                $('#exampleAddEditModalCenter').find('[name="input-first-name"]').val('');
                $('#exampleAddEditModalCenter').find('[name="input-last-name"]').val('');
                $('#exampleAddEditModalCenter').find('[name="input-email"]').val('');
                $('#exampleAddEditModalCenter').find('[name="input-mobile').val('');
                $('#exampleAddEditModalCenter').find('[name="input-address1"]').val('');
                $('#exampleAddEditModalCenter').find('[name="choose-country"]').val('');
                $('#exampleAddEditModalCenter').find('[name="input-city"]').val('');
                $('#exampleAddEditModalCenter').find('[name="input-state"]').val('');
                $('#exampleAddEditModalCenter').find('[name="input-zip"]').val('');
                $('#exampleAddEditModalCenter').find('[name="choose-as-default-addr"]')[0].checked = false;
                $("#exampleAddEditModalCenter").modal('hide');
            })
        });

        $('#exampleModalCenter').on('show.bs.modal', function (e) {
            // get information to update quickly to modal view as loading begins
            var opener=e.relatedTarget;//this holds the element who called the modal

            $(document).on('click', '#btn-confirm', function(e) {
                e.preventDefault();
                
                var def_address_id = $('input[name="flexRadioDefault"]:checked').val();

                $.ajax({
                    data: { def_address_id: def_address_id},
                    type: "post",
                    url: "crud/address/update-2.php",
                    success: function(res) {
                            // alert(res);
                            location.reload();
                        }
                    });
            });
        });
    </script>
</body>

</html>