<?php

if (isset($_GET["prod_id"])) {
    $prodID = $_GET["prod_id"];
    $userName = $_POST["user_name"];
    $userEmail = $_POST["user_email"];
    $userReview = $_POST["user_review"];

    try {
        include_once "config/config.php";
    
        //echo "Connection has been set successfully";
        $sql = "INSERT INTO prod_review(prod_id, name, email, review)VALUES(:prod_id, :name, :email, :review)";
        $pdo_statement = $pdo_conn->prepare($sql);
            
        $result = $pdo_statement->execute(array(':prod_id'=>$prodID, 
                                                ':name'=>$userName,
                                                ':email'=>$userEmail,
                                                ':review'=>$userReview));
        header("Location: http://localhost/kdshopclient/detail.php?prod_id=" . $prodID);
        exit;
    } catch (PDOException $e) {
        echo $e;
    }
}