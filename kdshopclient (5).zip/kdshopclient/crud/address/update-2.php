<?php

$def_address_id = $_POST['def_address_id'];

try {
    include_once "../../config/config.php";

    $sql = "UPDATE billing_address SET is_default = 0 WHERE addr_id = (SELECT addr_id FROM billing_address WHERE is_default = 1)";
    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute();
	
    $sql = "UPDATE billing_address SET is_default = 1 WHERE addr_id = :def_address_id";
    $pdo_statement = $pdo_conn->prepare($sql);
    $result = $pdo_statement->execute(array(':def_address_id'=>$def_address_id));
   
} catch (PDOException $e) {
    echo $e;
}

?>