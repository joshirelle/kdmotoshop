(function ($) {
    "use strict";
    
    // Dropdown on mouse hover
    $(document).ready(function () {
        function toggleNavbarMethod() {
            if ($(window).width() > 992) {
                $('.navbar .dropdown').on('mouseover', function () {
                    $('.dropdown-toggle', this).trigger('click');
                }).on('mouseout', function () {
                    $('.dropdown-toggle', this).trigger('click').blur();
                });
            } else {
                $('.navbar .dropdown').off('mouseover').off('mouseout');
            }
        }
        toggleNavbarMethod();
        $(window).resize(toggleNavbarMethod);
    });
    
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Vendor carousel
    $('.vendor-carousel').owlCarousel({
        loop: true,
        margin: 29,
        nav: false,
        autoplay: true,
        smartSpeed: 1000,
        responsive: {
            0:{
                items:2
            },
            576:{
                items:3
            },
            768:{
                items:4
            },
            992:{
                items:5
            },
            1200:{
                items:6
            }
        }
    });


    // Related carousel
    $('.related-carousel').owlCarousel({
        loop: true,
        margin: 29,
        nav: false,
        autoplay: true,
        smartSpeed: 1000,
        responsive: {
            0:{
                items:1
            },
            576:{
                items:2
            },
            768:{
                items:3
            },
            992:{
                items:4
            }
        }
    });


    // Product Quantity
    $('.quantity button').on('click', function () {
        var button = $(this);
        var oldValue = button.parent().parent().find('input').val();
        if (button.hasClass('btn-plus')) {
            var newVal = parseFloat(oldValue) + 1;
        } else {
            if (oldValue > 0) {
                var newVal = parseFloat(oldValue) - 1;
            } else {
                newVal = 0;
            }
        }
        button.parent().parent().find('input').val(newVal);
    });


    $('#shipto').on('change', function() {
        $('#first_name').prop('disabled', (this.checked) ? true : false);
        $('#first_name').prop('required', (this.checked) ? false : true);

        $('#last_name').prop('disabled', (this.checked) ? true : false);
        $('#last_name').prop('required', (this.checked) ? false : true);

        $('#email').prop('disabled', (this.checked) ? true : false);
        $('#email').prop('required', (this.checked) ? false : true);

        $('#night_phone_c').prop('disabled', (this.checked) ? true : false);
        $('#night_phone_c').prop('required', (this.checked) ? false : true);

        $('#address1').prop('disabled', (this.checked) ? true : false);
        $('#address1').prop('required', (this.checked) ? false : true);

        $('#country').prop('disabled', (this.checked) ? true : false);
        $('#country').prop('required', (this.checked) ? false : true);

        $('#city').prop('disabled', (this.checked) ? true : false);
        $('#city').prop('required', (this.checked) ? false : true);

        $('#state').prop('disabled', (this.checked) ? true : false);
        $('#state').prop('required', (this.checked) ? false : true);

        $('#zip').prop('disabled', (this.checked) ? true : false);
        $('#zip').prop('required', (this.checked) ? false : true);

        $('#shipping-address #first_name').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #first_name').prop('required', (this.checked) ? true : false);

        $('#shipping-address #last_name').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #last_name').prop('required', (this.checked) ? true : false);

        $('#shipping-address #email').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #email').prop('required', (this.checked) ? true : false);

        $('#shipping-address #night_phone_c').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #night_phone_c').prop('required', (this.checked) ? true : false);

        $('#shipping-address #address1').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #address1').prop('required', (this.checked) ? true : false);

        $('#shipping-address #country').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #country').prop('required', (this.checked) ? true : false);

        $('#shipping-address #city').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #city').prop('required', (this.checked) ? true : false);

        $('#shipping-address #state').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #state').prop('required', (this.checked) ? true : false);

        $('#shipping-address #zip').prop('disabled', (this.checked) ? false : true);
        $('#shipping-address #zip').prop('required', (this.checked) ? true : false);
    });


   
    
})(jQuery);

