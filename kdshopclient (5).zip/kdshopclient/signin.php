<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>KDMotoshop | Sign In</title>
	<link rel="stylesheet" type="text/css" href="css/signin-style.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="wrapper">
		<section class="form signin">
			<header>Realtime Chat App</header>
			<form action="#">
				<div class="error-txt">This is an error message!</div>
				<div class="field input">
					<label>Email Address</label>
					<input type="text" placeholder="Enter your email">
				</div>
				<div class="field input">
					<label>Password</label>
					<input type="password" placeholder="Enter your password">
					<i class="fa fa-eye"></i>
				</div>
				<div class="field button">
					<input type="submit" value="Login">
				</div>
			</form>
			<div class="link">Not yet Signed Up? <a href="signup.php">Sign Up</div>
		</section>
	</div>
</body>
</html>