<?php
session_start();
unset($_SESSION["cart_item"]);
header("Location: http://localhost/kdshopclient/index.php");
?>
<h1>Sorry! Your PayPal Payment has been cancelled.</h1>