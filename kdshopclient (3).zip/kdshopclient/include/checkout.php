<!-- Checkout Start -->
<div class="container-fluid">
    <form method='post' action='https://www.sandbox.paypal.com/cgi-bin/webscr'>
        <div class="row px-xl-5">
            <div class="col-lg-8">
            <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Billing Address</span></h5>
                <div class="bg-light p-30 mb-5">
                    <div class="row">
                        <input type="hidden" name="address_override" value="1">
                        <div class="col-md-6 form-group">
                            <label>First Name</label>
                            <input class="form-control" type="text" name="first_name" id="first_name" placeholder="John" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Last Name</label>
                            <input class="form-control" type="text" name="last_name" id="last_name" placeholder="Doe" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>E-mail</label>
                            <input class="form-control" type="text" name="email" id="email" placeholder="example@email.com" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Mobile No</label>
                            <input class="form-control" type="text" name="night_phone_c" id="night_phone_c" placeholder="+123 456 789" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Address Line 1</label>
                            <input class="form-control" type="text" name="address1" id="address1" placeholder="123 Street" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Country</label>
                            <select class="custom-select" name="country" id="country" required>
                                <option selected>Philippines</option>
                            </select>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>City</label>
                            <input class="form-control" type="text" name="city" id="city" placeholder="New York" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>State</label>
                            <input class="form-control" type="text" name="state" id="state" placeholder="New York" required>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>ZIP Code</label>
                            <input class="form-control" type="text" name="zip" id="zip" placeholder="123" required>
                        </div>
                       <!--  <div class="col-md-12 form-group">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="newaccount">
                                <label class="custom-control-label" for="newaccount">Create an account</label>
                            </div>
                        </div> -->
                        <div class="col-md-12">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="shipto">
                                <label class="custom-control-label" for="shipto"  data-toggle="" data-target="#shipping-address">Ship to different address</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=" mb-5">
                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Shipping Address</span></h5>
                    <div class="bg-light p-30" id="shipping-address">
                        <div class="row">
                            <input type="hidden" name="address_override" value="1">
                        <div class="col-md-6 form-group">
                            <label>First Name</label>
                            <input class="form-control" type="text" name="first_name" id="first_name" placeholder="John" disabled>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Last Name</label>
                            <input class="form-control" type="text" name="last_name"  id="last_name" placeholder="Doe" disabled>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>E-mail</label>
                            <input class="form-control" type="text" name="email"  id="email" placeholder="example@email.com" disabled>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Mobile No</label>
                            <input class="form-control" type="text" name="night_phone_c"  id="night_phone_c" placeholder="+123 456 789" disabled>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>Address Line 1</label>
                            <input class="form-control" type="text" name="address1"  id="address1" placeholder="123 Street" disabled>
                        </div>
                        <!-- <div class="col-md-6 form-group">
                            <label>Address Line 2</label>
                            <input class="form-control" type="text" placeholder="123 Street" required>
                        </div> -->
                        <div class="col-md-6 form-group">
                            <label>Country</label>
                            <select class="custom-select" name="country" id="country" disabled>
                                <option selected>Philippines</option>
                            </select>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>City</label>
                            <input class="form-control" type="text" name="city"  id="city" placeholder="New York" disabled>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>State</label>
                            <input class="form-control" type="text" name="state"  id="state" placeholder="New York" disabled>
                        </div>
                        <div class="col-md-6 form-group">
                            <label>ZIP Code</label>
                            <input class="form-control" type="text" name="zip"  id="zip" placeholder="123" disabled>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Order Total</span></h5>
                <div class="bg-light p-30 mb-5">
                    <div class="border-bottom">
                        <h6 class="mb-3">Products</h6>
                        <?php
                            $total = 0;
                            if (!empty($_SESSION["cart_item"])){
                                foreach ($_SESSION["cart_item"] as $item){
                                    // var_dump($item);
                                    $total += (float)$item["price"] * (int)$item["qty"];
                        ?>
                            <div class="d-flex justify-content-between">
                            <p><?php echo $item["name"]; ?></p>
                            <p><?php echo $total; ?></p>
                        </div>
                        <?php 
                             }
                            }
                        ?>
                    </div>
                    <div class="border-bottom pt-3 pb-2">
                        <div class="d-flex justify-content-between mb-3">
                        <h6>Subtotal</h6>
                        <?php
                            $product = "";
                            $subtotal = 0;
                            $itemNumber = 0;
                            
                            if (!empty($_SESSION["cart_item"])){
                                foreach ($_SESSION["cart_item"] as $item){
                                    $arr[] = (string)$item["name"];
                                    $array_string = implode(", ", $arr);
                                    $subtotal += (float)$item["price"] * (int)$item["qty"];
                                    $itemNumber = $item["prod_id"];
                                }
                            }
                            ?>
                            <h6><?php echo $subtotal; ?></h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">Shipping</h6>
                            <h6 class="font-weight-medium">0.00</h6>
                        </div>
                    </div>
                    <div class="pt-2">
                        <div class="d-flex justify-content-between mt-2">
                            <h5>Total</h5>
                            <h5><?php echo $subtotal; ?></h5>
                        </div>
                    </div>
                </div>
                <div class="mb-5">
                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Payment</span></h5>
                    <div class="bg-light p-30">
                         <!-- method='post' action='https://www.sandbox.paypal.com/cgi-bin/webscr' -->
                        <div class="form-group">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment" id="paypal" checked>
                                <label class="custom-control-label" for="paypal">Paypal</label>
                            </div>
                        </div>
                        <input type='hidden' name='business' value='sb-wekve26132175@business.example.com'>
                        <input type='hidden' name='item_number' value='<?php echo $itemNumber; ?>'>
                        <input type='hidden' name='item_name' value='<?php echo $array_string; ?>'>
                        <input type='hidden' name='amount' value='<?php echo $subtotal; ?>'>
                        <input type='hidden' name='currency_code' value='PHP'>

                        <!-- <input type="hidden" name="first_name" value="Pedro">
                        <input type="hidden" name="last_name" value="Penduko">
                        <input type="hidden" name="address1" value="345 Lark Aveasdasd">
                        <input type="hidden" name="city" value="San Jose"> 
                        <input type="hidden" name="state" value="CA"> 
                        <input type="hidden" name="zip" value="95121">  -->

                        <input type="hidden" name="country" value="Philippines">
                        <!-- <input type='hidden' name='return' value='http://localhost/kdshopclient/unset_session.php'> -->
                        <input type='hidden' name='return' value='http://localhost/kdshopclient/tracking.php'>
                        <input type='hidden' name='cancel_return' value='http://localhost/kdshopclient/cancel_return.php'>
                        <!-- <input type='hidden' name='notify_url' value='http://localhost/kdshopclient/notify.php'> -->
                        <input type="hidden" name="cmd" value="_xclick">
                        <button type="submit" name="submit-btn" class="btn btn-block btn-primary font-weight-bold py-3 pay">
                        Place Order</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<!-- Checkout End -->